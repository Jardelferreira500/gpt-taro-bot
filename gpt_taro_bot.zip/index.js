const express = require("express");
const axios = require("axios");
const app = express();

app.use(express.json());

const openaiApiKey = "SUA_CHAVE_OPENAI";
const zapiToken = "SEU_TOKEN_ZAPI";
const instanciaID = "SEU_ID_INSTANCIA";

app.post("/webhook", async (req, res) => {
  const mensagem = req.body.message.body;
  const numero = req.body.message.from;

  try {
    const resposta = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      {
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "Você é uma taróloga chamada Luna de Gaia. Dê respostas profundas, espirituais e intuitivas com base no Tarô."
          },
          {
            role: "user",
            content: mensagem
          }
        ]
      },
      {
        headers: {
          Authorization: `Bearer ${openaiApiKey}`,
          "Content-Type": "application/json"
        }
      }
    );

    const respostaFinal = resposta.data.choices[0].message.content;

    await axios.post(
      `https://api.z-api.io/instances/${instanciaID}/token/${zapiToken}/send-message`,
      {
        phone: numero,
        message: respostaFinal
      }
    );

    res.sendStatus(200);
  } catch (error) {
    console.error(error.response?.data || error.message);
    res.sendStatus(500);
  }
});

app.listen(3000, () => console.log("Servidor rodando na porta 3000"));
